#!/bin/bash

# Update packages
echo "Updating package list..."
sudo apt-get update -y

# Install Node.js
echo "Installing Node.js..."
curl -sL https://deb.nodesource.com/setup_20.x | sudo -E bash - 
sudo apt-get install -y nodejs unzip

# Install MySQL
echo "Installing MySQL..."
sudo apt-get install -y mysql-server

# Start MySQL and enable it to start on boot
sudo systemctl start mysql
sudo systemctl enable mysql

# Check MySQL status
if sudo systemctl status mysql | grep -q "running"; then
    echo "MySQL is running."
else
    echo "MySQL failed to start."
    exit 1
fi


sudo mysql --execute="CREATE DATABASE ${DB_NAME};"
if [ $? -eq 0 ]; then
    echo "Database ${DB_NAME} created successfully."
else
    echo "Failed to create database ${DB_NAME}."
    exit 1
fi

sudo mysql --execute="CREATE USER '${DB_USER}'@'localhost' IDENTIFIED WITH mysql_native_password BY '${DB_PASSWORD}';"
if [ $? -eq 0 ]; then
    echo "User ${DB_USER} created successfully."
else
    echo "Failed to create user ${DB_USER}."
    exit 1
fi

sudo mysql --execute="GRANT ALL PRIVILEGES ON ${DB_NAME}.* TO '${DB_USER}'@'localhost';"
if [ $? -eq 0 ]; then
    echo "Privileges granted to user ${DB_USER} on database ${DB_NAME}."
else
    echo "Failed to grant privileges to user ${DB_USER}."
    exit 1
fi

sudo mysql --execute="FLUSH PRIVILEGES;"
if [ $? -eq 0 ]; then
    echo "Privileges flushed successfully."
else
    echo "Failed to flush privileges."
    exit 1
fi

echo ".env file created successfully."
